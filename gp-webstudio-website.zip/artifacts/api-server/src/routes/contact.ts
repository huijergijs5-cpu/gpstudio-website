import { Router, type IRouter, type Request } from "express";
import { SubmitContactRequestBody, SubmitContactRequestResponse } from "@workspace/api-zod";
import { db } from "@workspace/db";
import { contactRequestsTable } from "@workspace/db/schema";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const recentRequests = new Map<string, number>();
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000;

function getClientKey(req: Request) {
  const forwarded = req.headers["x-forwarded-for"];
  return typeof forwarded === "string" ? forwarded.split(",")[0].trim() : req.ip ?? "unknown";
}

router.post("/contact", async (req, res) => {
  const parsed = SubmitContactRequestBody.safeParse(req.body);

  if (!parsed.success) {
    res.status(400).json({ error: "Controleer de ingevulde gegevens en probeer opnieuw." });
    return;
  }

  const clientKey = getClientKey(req);
  const lastRequest = recentRequests.get(clientKey);
  if (lastRequest && Date.now() - lastRequest < RATE_LIMIT_WINDOW_MS) {
    res.status(429).json({ error: "Je aanvraag is al ontvangen. Probeer het later opnieuw." });
    return;
  }

  const data = parsed.data;
  if (!data.privacyAccepted) {
    res.status(400).json({ error: "Je moet akkoord gaan met de privacyverklaring." });
    return;
  }

  // Honeypot submissions are acknowledged without being stored.
  if (data.honeypot.trim().length > 0) {
    res.status(201).json(
      SubmitContactRequestResponse.parse({
        success: true,
        message: "Bedankt voor je aanvraag.",
      }),
    );
    return;
  }

  try {
    await db.insert(contactRequestsTable).values({
      name: data.name.trim(),
      company: data.company?.trim() || null,
      email: data.email.trim().toLowerCase(),
      phone: data.phone?.trim() || null,
      websiteType: data.websiteType,
      websiteUrl: data.websiteUrl?.trim() || null,
      budget: data.budget,
      timeline: data.timeline?.trim() || null,
      message: data.message.trim(),
      privacyAccepted: data.privacyAccepted,
    });

    recentRequests.set(clientKey, Date.now());
    const recipient = process.env.CONTACT_EMAIL;
    logger.info(
      {
        recipientConfigured: Boolean(recipient),
        senderDomain: data.email.split("@")[1] ?? "unknown",
      },
      "Contact request accepted",
    );

    res.status(201).json(
      SubmitContactRequestResponse.parse({
        success: true,
        message: "Bedankt voor je aanvraag. Ik neem zo snel mogelijk contact met je op.",
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Could not store contact request");
    res.status(500).json({ error: "De aanvraag kon niet worden verwerkt. Probeer het opnieuw." });
  }
});

export default router;