import { type FormEvent, type ReactNode, useEffect, useState } from 'react';
import { useSubmitContactRequest } from '@workspace/api-client-react';
import {
  ArrowDown,
  ArrowUpRight,
  Check,
  CircleCheck,
  Code2,
  Menu,
  MoveRight,
  Quote,
  X,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ErrorBoundary } from '@/components/error-boundary';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();

type WebsiteType = 'bedrijfswebsite' | 'webshop' | 'landingpage' | 'boekingswebsite' | 'bestelsite' | 'portfolio' | 'redesign' | 'maatwerk' | 'weet-ik-nog-niet';
type Budget = 'nog-niet-bepaald' | 'minder-dan-500' | '500-1000' | '1000-2500' | '2500-plus' | 'eerst-overleggen';

const initialForm = {
  name: '',
  company: '',
  email: '',
  phone: '',
  websiteType: 'bedrijfswebsite' as WebsiteType,
  websiteUrl: '',
  budget: 'nog-niet-bepaald' as Budget,
  timeline: '',
  message: '',
  privacyAccepted: false,
  honeypot: '',
};

const navItems = [
  { href: '#diensten', label: 'Diensten' },
  { href: '#werk', label: 'Portfolio' },
  { href: '#aanpak', label: 'Werkwijze' },
  { href: '#over-ons', label: 'Over ons' },
  { href: '#contact', label: 'Contact' },
];

function Seo({
  title,
  description,
  path,
  structuredData,
}: {
  title: string;
  description: string;
  path: string;
  structuredData?: object;
}) {
  useEffect(() => {
    document.title = title;
    document.documentElement.lang = 'nl-BE';
    const canonicalUrl = `${window.location.origin}${path}`;

    const setMeta = (key: string, content: string, attribute = 'name') => {
      let element = document.head.querySelector<HTMLMetaElement>(`meta[${attribute}="${key}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, key);
        document.head.appendChild(element);
      }
      element.content = content;
    };

    setMeta('description', description);
    setMeta('og:title', title, 'property');
    setMeta('og:description', description, 'property');
    setMeta('og:url', canonicalUrl, 'property');
    setMeta('twitter:title', title);
    setMeta('twitter:description', description);

    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = canonicalUrl;

    document.head.querySelector('#gp-webstudio-structured-data')?.remove();
    if (structuredData) {
      const script = document.createElement('script');
      script.id = 'gp-webstudio-structured-data';
      script.type = 'application/ld+json';
      script.textContent = JSON.stringify(structuredData);
      document.head.appendChild(script);
    }
  }, [description, path, structuredData, title]);

  return null;
}

function Logo({ dark = false }: { dark?: boolean }) {
  return (
    <Link href="/" className="inline-flex items-center gap-3" data-testid="link-logo">
      <span className={`flex h-9 w-9 items-center justify-center rounded-[11px] ${dark ? 'bg-[#14D8A8] text-[#0B1F3B]' : 'bg-[#0B1F3B] text-white'}`}>
        <Code2 size={19} strokeWidth={2.5} />
      </span>
      <span className={`text-[15px] font-bold tracking-[-0.03em] ${dark ? 'text-white' : 'text-[#0B1F3B]'}`}>
        GP<span className={dark ? 'text-[#14D8A8]' : 'text-[#3B82F6]'}>.</span>webstudio
      </span>
    </Link>
  );
}

function Header() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  useEffect(() => setOpen(false), [location]);

  return (
    <header className="absolute inset-x-0 top-0 z-40">
      <div className="container-wide flex h-[78px] items-center justify-between">
        <Logo />
        <nav className="hidden items-center gap-8 md:flex" aria-label="Hoofdnavigatie">
          {navItems.map((item) => (
            <a href={item.href} key={item.href} className="nav-link text-[13px] font-semibold" data-testid={`link-nav-${item.label.toLowerCase()}`}>
              {item.label}
            </a>
          ))}
        </nav>
        <a href="#contact" className="btn-primary hidden py-2.5 text-[13px] md:inline-flex" data-testid="link-header-offerte">
          Bespreek je idee <ArrowUpRight size={15} />
        </a>
        <button
          type="button"
          className="flex h-10 w-10 items-center justify-center rounded-full border border-[#0B1F3B]/10 bg-white/60 text-[#0B1F3B] md:hidden"
          onClick={() => setOpen(!open)}
          aria-label={open ? 'Menu sluiten' : 'Menu openen'}
          aria-expanded={open}
          data-testid="button-mobile-menu"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
      <div className={`container-wide md:hidden ${open ? 'block' : 'hidden'}`}>
        <nav className="mt-1 rounded-2xl border border-[#0B1F3B]/10 bg-[#F6F8FB]/95 p-3 shadow-xl backdrop-blur-xl" aria-label="Mobiele navigatie">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} onClick={() => setOpen(false)} className="block rounded-xl px-4 py-3 text-sm font-semibold text-[#0B1F3B] hover:bg-[#0B1F3B]/5" data-testid={`link-mobile-${item.label.toLowerCase()}`}>
              {item.label}
            </a>
          ))}
          <a href="#contact" onClick={() => setOpen(false)} className="btn-primary mt-2 w-full text-sm" data-testid="link-mobile-offerte">Bespreek je idee <ArrowUpRight size={15} /></a>
        </nav>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative min-h-[690px] overflow-hidden bg-[#F6F8FB] pt-[78px]">
      <div className="hero-grid absolute inset-0 opacity-70" />
      <div className="absolute -right-32 top-28 h-80 w-80 rounded-full bg-[#14D8A8]/10 blur-3xl" />
      <div className="container-wide relative grid min-h-[610px] items-center gap-14 pb-20 pt-20 lg:grid-cols-[1.03fr_.97fr] lg:gap-8 lg:pb-16">
        <div className="max-w-[640px]">
          <div className="reveal inline-flex items-center gap-2 rounded-full border border-[#3B82F6]/20 bg-white/70 px-3 py-2 font-mono-ui text-[10px] font-bold uppercase tracking-[.12em] text-[#3B82F6]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#14D8A8]" /> Webstudio uit België
          </div>
          <h1 className="reveal delay-1 mt-7 max-w-[700px] text-balance text-[clamp(3.3rem,7.5vw,6.65rem)] font-semibold leading-[.92] tracking-[-.065em] text-[#0B1F3B]">
            Een professionele website die <span className="font-display font-normal italic text-[#3B82F6]">voor je werkt.</span>
          </h1>
          <p className="reveal delay-2 mt-7 max-w-[530px] text-[17px] leading-8 text-[#46546a]">
            GP Webstudio bouwt websites op maat die jouw bedrijf professioneel presenteren en bezoekers makkelijker maken om contact op te nemen, een offerte aan te vragen of klant te worden.
          </p>
          <div className="reveal delay-3 mt-9 flex flex-col items-start gap-3 sm:flex-row">
            <a href="#contact" className="btn-primary" data-testid="link-hero-offerte">Bespreek jouw website <MoveRight size={16} /></a>
            <a href="#werk" className="btn-secondary" data-testid="link-hero-werk">Bekijk ons werk <ArrowDown size={15} /></a>
          </div>
          <div className="reveal delay-4 mt-11 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-[#647188]">
            <span className="flex items-center gap-2"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#14D8A8]/15 text-[#0B1F3B]"><Check size={13} strokeWidth={3} /></span>Op maat gemaakt</span>
            <span className="hidden h-4 w-px bg-[#0B1F3B]/15 sm:block" />
            <span className="flex items-center gap-2"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#14D8A8]/15 text-[#0B1F3B]"><Check size={13} strokeWidth={3} /></span>Mobiel geoptimaliseerd</span>
            <span className="hidden h-4 w-px bg-[#0B1F3B]/15 sm:block" />
            <span className="flex items-center gap-2"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#14D8A8]/15 text-[#0B1F3B]"><Check size={13} strokeWidth={3} /></span>Persoonlijk contact</span>
          </div>
        </div>
        <div className="relative mx-auto w-full max-w-[520px] lg:ml-auto">
          <div className="drift relative rounded-[28px] border border-[#0B1F3B]/10 bg-[#0B1F3B] p-3 shadow-2xl">
            <div className="flex items-center gap-2 px-3 pb-3 pt-1">
              <span className="h-2 w-2 rounded-full bg-[#14D8A8]" /><span className="h-2 w-2 rounded-full bg-[#3B82F6]" /><span className="ml-1 font-mono-ui text-[9px] tracking-widest text-white/40">GP / PREVIEW</span>
            </div>
            <div className="relative min-h-[330px] overflow-hidden rounded-[19px] bg-[#dce8f2] p-5 sm:min-h-[390px] sm:p-7">
              <div className="absolute right-[-50px] top-[-70px] h-64 w-64 rounded-full bg-[#14D8A8]/50 blur-[2px]" />
              <div className="absolute bottom-[-100px] left-[-30px] h-64 w-64 rounded-full bg-[#3B82F6]/45" />
              <div className="relative flex items-center justify-between">
                <span className="font-mono-ui text-[10px] font-bold tracking-[.15em] text-[#0B1F3B]">ATELIER / 01</span>
                <span className="rounded-full bg-[#0B1F3B] px-2.5 py-1 font-mono-ui text-[8px] text-white">CONCEPT</span>
              </div>
              <div className="relative mt-20 max-w-[265px]">
                <p className="font-display text-[53px] leading-[.86] tracking-[-.05em] text-[#0B1F3B]">Ruimte voor wat telt.</p>
                <div className="mt-5 h-1 w-16 bg-[#3B82F6]" />
                <p className="mt-5 max-w-[200px] text-[10px] leading-4 text-[#0B1F3B]/65">Een digitale plek die voelt zoals je werk.</p>
              </div>
              <div className="absolute bottom-5 right-5 flex h-12 w-12 items-center justify-center rounded-full bg-[#0B1F3B] text-white"><ArrowUpRight size={18} /></div>
              <div className="absolute bottom-6 left-5 font-mono-ui text-[8px] text-[#0B1F3B]/55">DIGITAAL ATELIER — BELGIË</div>
            </div>
          </div>
          <div className="absolute -bottom-7 -left-6 hidden rounded-2xl border border-[#14D8A8]/35 bg-white/90 p-4 shadow-xl backdrop-blur sm:block">
            <div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#14D8A8]/15 text-[#0B1F3B]"><CircleCheck size={19} /></span><div><p className="font-mono-ui text-[9px] uppercase tracking-wider text-[#647188]">Focus</p><p className="mt-0.5 text-sm font-bold text-[#0B1F3B]">Duidelijkheid eerst</p></div></div>
          </div>
        </div>
      </div>
      <a href="#diensten" className="absolute bottom-7 left-1/2 hidden -translate-x-1/2 items-center gap-2 font-mono-ui text-[9px] uppercase tracking-[.16em] text-[#647188] lg:flex" data-testid="link-scroll-diensten">Scroll om te ontdekken <ArrowDown size={13} /></a>
    </section>
  );
}

function IntroBand() {
  return (
    <section className="border-y border-[#0B1F3B]/10 bg-[#0B1F3B] py-7 text-white">
      <div className="container-wide flex flex-col justify-between gap-5 md:flex-row md:items-center">
        <p className="max-w-[570px] text-lg leading-7 tracking-[-.02em] text-white/80">Geen ruis. Geen onnodige lagen. <span className="text-[#14D8A8]">Wel een website die voor je werkt.</span></p>
        <p className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-white/40">Van eerste schets tot live</p>
      </div>
    </section>
  );
}

function WhyWebsite() {
  const benefits = [
    'Vertrouwen opbouwen bij potentiële klanten',
    'Duidelijk maken wat je aanbiedt',
    'Professioneel werken op telefoon, tablet en desktop',
    'Bezoekers eenvoudig richting contact begeleiden',
    'Diensten, producten, boekingen of aanvragen beter presenteren',
  ];
  return (
    <section className="section-pad bg-[#0B1F3B] text-white">
      <div className="container-wide grid gap-12 lg:grid-cols-[.9fr_1.1fr] lg:items-end">
        <div>
          <p className="eyebrow text-[#14D8A8]">Waarom dit telt</p>
          <h2 className="mt-5 max-w-[520px] text-4xl font-semibold leading-[1.02] tracking-[-.05em] sm:text-6xl">Je website is vaak het eerste <span className="font-display font-normal italic text-[#14D8A8]">gesprek.</span></h2>
          <p className="mt-6 max-w-[470px] leading-7 text-white/65">Een verouderde, onduidelijke of slecht werkende website kan ervoor zorgen dat bezoekers afhaken. Een goede website helpt potentiële klanten om sneller te begrijpen waarom ze voor jouw bedrijf kunnen kiezen.</p>
          <a href="#contact" className="btn-primary mt-8 bg-[#14D8A8] text-[#0B1F3B] hover:bg-[#32e4ba]" data-testid="link-why-contact">Bespreek mijn website <ArrowUpRight size={15} /></a>
        </div>
        <ul className="border-t border-white/15">
          {benefits.map((benefit, index) => (
            <li key={benefit} className="flex items-start gap-4 border-b border-white/15 py-5 text-lg leading-6 text-white/85">
              <span className="font-mono-ui text-[10px] text-[#14D8A8]">0{index + 1}</span>
              <span>{benefit}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Services() {
  const services = [
    { number: '01', title: 'Bedrijfswebsite', text: 'Voor bedrijven die professioneel online zichtbaar willen zijn en helder willen tonen wat ze aanbieden.' },
    { number: '02', title: 'Website voor zelfstandigen', text: 'Laat zien wie je bent, wat je doet en waarom een potentiële klant precies jou moet contacteren.' },
    { number: '03', title: 'Webshop & booking', text: 'Verkoop producten of maak reservaties eenvoudig met een rustige route van interesse naar actie.' },
    { number: '04', title: 'Landingpage & campagnes', text: 'Leid bezoekers van een campagne naar één duidelijke actie, zonder afleiding.' },
    { number: '05', title: 'Redesign', text: 'Maak een bestaande website opnieuw duidelijk, professioneel en prettig op elk scherm.' },
    { number: '06', title: 'Maatwerk', text: 'Geen standaardoplossing, maar functies afgestemd op wat jouw bedrijf echt nodig heeft.' },
  ];
  return (
    <section id="diensten" className="section-pad bg-[#F6F8FB]">
      <div className="container-wide">
        <div className="grid gap-8 lg:grid-cols-[.72fr_1.28fr]">
          <div>
            <p className="eyebrow">Wat we maken</p>
            <h2 className="mt-5 max-w-[380px] text-4xl font-semibold leading-[1.03] tracking-[-.05em] text-[#0B1F3B] sm:text-5xl">Digitaal werk dat <span className="font-display font-normal italic text-[#3B82F6]">klopt.</span></h2>
            <p className="mt-6 max-w-[355px] leading-7 text-[#647188]">We bouwen niet alleen een mooie website. We maken het makkelijker om vertrouwen op te bouwen, je aanbod duidelijk te presenteren en bezoekers richting contact te begeleiden.</p>
            <a href="#contact" className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-[#0B1F3B] underline decoration-[#14D8A8] decoration-2 underline-offset-8" data-testid="link-services-contact">Ontdek de mogelijkheden <ArrowUpRight size={15} /></a>
          </div>
          <div className="grid border-t border-[#0B1F3B]/15 sm:grid-cols-2">
            {services.map((service) => (
              <div key={service.number} className="group border-b border-[#0B1F3B]/15 py-7 sm:even:pl-8 sm:odd:pr-8">
                <div className="flex items-start justify-between"><span className="font-mono-ui text-[10px] text-[#3B82F6]">{service.number}</span><ArrowUpRight size={16} className="text-[#9aa5b5] transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" /></div>
                <h3 className="mt-8 text-xl font-bold tracking-[-.03em] text-[#0B1F3B]">{service.title}</h3>
                <p className="mt-3 max-w-[280px] text-sm leading-6 text-[#647188]">{service.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Portfolio() {
  const concepts = [
    { label: 'Demo-concept / dienstverlener', title: 'Van expertise naar vertrouwen.', focus: 'Focus: aanbod helder presenteren', tone: 'blue', number: '01' },
    { label: 'Demo-concept / lokaal merk', title: 'Een plek met eigen karakter.', focus: 'Focus: herkenning en contact', tone: 'mint', number: '02' },
    { label: 'Demo-concept / persoonlijk project', title: 'Gemaakt om te blijven hangen.', focus: 'Focus: verhaal en richting', tone: 'navy', number: '03' },
  ];
  return (
    <section id="werk" className="section-pad bg-[#eaf0f6]">
      <div className="container-wide">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div><p className="eyebrow">Werk in wording</p><h2 className="mt-5 max-w-[570px] text-4xl font-semibold leading-[.98] tracking-[-.055em] text-[#0B1F3B] sm:text-6xl">Concepten die tonen<br /><span className="font-display font-normal italic text-[#3B82F6]">hoe het kan voelen.</span></h2></div>
          <p className="max-w-[270px] text-sm leading-6 text-[#647188]">Dit zijn demo-concepten: ontworpen om richting te geven, niet om fictieve klanten of resultaten te veinzen.</p>
        </div>
        <div className="mt-14 grid gap-5 lg:grid-cols-[1.1fr_.9fr_.9fr]">
          {concepts.map((concept, index) => (
            <article key={concept.number} className={`${index === 0 ? 'lg:translate-y-10' : ''} group`}>
              <div className={`relative min-h-[350px] overflow-hidden rounded-[22px] p-5 transition-transform duration-500 group-hover:-translate-y-2 sm:min-h-[400px] ${concept.tone === 'blue' ? 'bg-[#3B82F6]' : concept.tone === 'mint' ? 'bg-[#14D8A8]' : 'bg-[#0B1F3B]'}`}>
                <div className="flex items-center justify-between"><span className={`font-mono-ui text-[9px] uppercase tracking-[.15em] ${concept.tone === 'navy' ? 'text-white/55' : 'text-[#0B1F3B]/60'}`}>{concept.label}</span><span className={`font-mono-ui text-xs ${concept.tone === 'navy' ? 'text-[#14D8A8]' : 'text-[#0B1F3B]/60'}`}>{concept.number}</span></div>
                <div className={`absolute inset-x-5 bottom-5 rounded-[15px] p-5 ${concept.tone === 'blue' ? 'bg-[#0B1F3B] text-white' : concept.tone === 'mint' ? 'bg-[#F6F8FB] text-[#0B1F3B]' : 'border border-white/15 bg-white/10 text-white backdrop-blur'}`}>
                  <div className="flex items-end justify-between gap-3"><div><h3 className="max-w-[230px] text-2xl font-semibold leading-[1.02] tracking-[-.04em]">{concept.title}</h3><p className={`mt-3 text-xs ${concept.tone === 'mint' ? 'text-[#647188]' : 'text-white/65'}`}>{concept.focus}</p></div><ArrowUpRight size={19} className={concept.tone === 'mint' ? 'text-[#3B82F6]' : 'text-[#14D8A8]'} /></div>
                  <div className={`mt-5 h-1 w-12 ${concept.tone === 'mint' ? 'bg-[#3B82F6]' : 'bg-[#14D8A8]'}`} />
                </div>
                <div className={`absolute right-[-25px] top-20 h-44 w-44 rounded-full border-[18px] ${concept.tone === 'blue' ? 'border-[#14D8A8]/50' : concept.tone === 'mint' ? 'border-[#3B82F6]/25' : 'border-[#3B82F6]/55'}`} />
              </div>
              <p className="mt-4 font-mono-ui text-[9px] uppercase tracking-[.14em] text-[#647188]">Visuele richting · geen live klantproject</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Approach() {
  const steps = [
    ['01', 'Vertel wat je nodig hebt', 'We bespreken jouw bedrijf, doelen en wensen.'],
    ['02', 'Je krijgt een voorstel', 'We spreken vooraf duidelijk af wat er gebouwd wordt.'],
    ['03', 'Wij bouwen jouw website', 'Ontwerp en ontwikkeling gaan hand in hand, met korte feedbackrondes.'],
    ['04', 'Feedback & oplevering', 'Na feedback wordt alles netjes afgewerkt en opgeleverd.'],
  ];
  return (
    <section id="aanpak" className="section-pad bg-[#F6F8FB]">
      <div className="container-wide">
        <div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr]">
          <div><p className="eyebrow">Onze manier van werken</p><h2 className="mt-5 max-w-[400px] text-4xl font-semibold leading-[1.03] tracking-[-.05em] text-[#0B1F3B] sm:text-5xl">Rust in het proces. <span className="font-display font-normal italic text-[#3B82F6]">Richting in het resultaat.</span></h2></div>
          <div className="grid border-t border-[#0B1F3B]/15 sm:grid-cols-2">
            {steps.map(([number, title, text]) => <div key={number} className="border-b border-[#0B1F3B]/15 py-7 sm:pr-8"><span className="font-mono-ui text-[10px] text-[#3B82F6]">{number}</span><h3 className="mt-7 text-lg font-bold text-[#0B1F3B]">{title}</h3><p className="mt-2 max-w-[290px] text-sm leading-6 text-[#647188]">{text}</p></div>)}
          </div>
        </div>
        <div className="mt-20 grid overflow-hidden rounded-[26px] bg-[#0B1F3B] lg:grid-cols-[1.2fr_.8fr]">
          <div className="p-8 sm:p-12"><Quote className="text-[#14D8A8]" size={30} /><p className="mt-7 max-w-[640px] text-3xl leading-[1.08] tracking-[-.04em] text-white sm:text-4xl">“Een goede website hoeft niet luid te zijn. Ze moet de juiste dingen helder maken.”</p><p className="mt-7 font-mono-ui text-[10px] uppercase tracking-[.15em] text-white/45">De ontwerpgedachte van GP</p></div>
          <div className="relative min-h-[230px] overflow-hidden bg-[#3B82F6]"><div className="absolute right-[-40px] top-[-40px] h-64 w-64 rounded-full border-[38px] border-[#14D8A8]/70" /><div className="absolute bottom-8 left-8 font-display text-6xl italic text-[#0B1F3B]/80">helder.</div></div>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const mutation = useSubmitContactRequest();
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const update = (key: keyof typeof initialForm, value: string | boolean) => setForm((current) => ({ ...current, [key]: value }));
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatus('idle');
    mutation.mutate({ data: form }, {
      onSuccess: () => {
        setStatus('success');
        setForm(initialForm);
      },
      onError: () => setStatus('error'),
    });
  };
  return (
    <section id="contact" className="section-pad bg-[#eaf0f6]">
      <div className="container-wide grid gap-12 lg:grid-cols-[.75fr_1.25fr] lg:gap-20">
        <div>
          <p className="eyebrow">Start hier</p>
          <h2 className="mt-5 max-w-[430px] text-5xl font-semibold leading-[.95] tracking-[-.06em] text-[#0B1F3B] sm:text-6xl">Een goed idee begint met een <span className="font-display font-normal italic text-[#3B82F6]">gesprek.</span></h2>
          <p className="mt-7 max-w-[380px] leading-7 text-[#647188]">Vertel in grote lijnen waar je naartoe wil. Je hoeft nog niet alles te weten: je krijgt een eerlijk antwoord op wat jouw bedrijf nodig heeft.</p>
          <div className="mt-10 space-y-4 border-t border-[#0B1F3B]/15 pt-6 text-sm text-[#46546a]">
            <div className="flex items-center gap-3"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#14D8A8]/20 text-[#0B1F3B]"><Check size={14} /></span>Vrijblijvende eerste inschatting</div>
            <div className="flex items-center gap-3"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#14D8A8]/20 text-[#0B1F3B]"><Check size={14} /></span>Duidelijke taal, geen verborgen jargon</div>
            <div className="flex items-center gap-3"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#14D8A8]/20 text-[#0B1F3B]"><Check size={14} /></span>Ook als je nog niet alles weet</div>
          </div>
        </div>
        <form onSubmit={submit} className="soft-card rounded-[24px] p-5 sm:p-8" data-testid="form-contact">
          <div className="grid gap-5 sm:grid-cols-2">
            <div><label className="form-label" htmlFor="name">Naam <span className="text-[#3B82F6]">*</span></label><input id="name" required minLength={2} maxLength={120} className="input-field" value={form.name} onChange={(e) => update('name', e.target.value)} placeholder="Je naam" data-testid="input-name" /></div>
            <div><label className="form-label" htmlFor="company">Bedrijf <span className="font-normal text-[#647188]">(optioneel)</span></label><input id="company" maxLength={160} className="input-field" value={form.company} onChange={(e) => update('company', e.target.value)} placeholder="Naam van je bedrijf" data-testid="input-company" /></div>
            <div><label className="form-label" htmlFor="email">E-mailadres <span className="text-[#3B82F6]">*</span></label><input id="email" required type="email" maxLength={254} className="input-field" value={form.email} onChange={(e) => update('email', e.target.value)} placeholder="jij@voorbeeld.be" data-testid="input-email" /></div>
            <div><label className="form-label" htmlFor="phone">Telefoon <span className="font-normal text-[#647188]">(optioneel)</span></label><input id="phone" maxLength={40} className="input-field" value={form.phone} onChange={(e) => update('phone', e.target.value)} placeholder="+32 ..." data-testid="input-phone" /></div>
            <div><label className="form-label" htmlFor="websiteType">Wat wil je maken? <span className="text-[#3B82F6]">*</span></label><select id="websiteType" required className="input-field" value={form.websiteType} onChange={(e) => update('websiteType', e.target.value)} data-testid="select-website-type"><option value="bedrijfswebsite">Bedrijfswebsite</option><option value="webshop">Webshop</option><option value="landingpage">Landing page</option><option value="boekingswebsite">Boekingswebsite</option><option value="bestelsite">Bestelsite</option><option value="portfolio">Portfolio</option><option value="redesign">Redesign</option><option value="maatwerk">Maatwerk</option><option value="weet-ik-nog-niet">Ik weet het nog niet</option></select></div>
            <div><label className="form-label" htmlFor="budget">Budgetrichting <span className="font-normal text-[#647188]">(optioneel)</span></label><select id="budget" className="input-field" value={form.budget} onChange={(e) => update('budget', e.target.value)} data-testid="select-budget"><option value="nog-niet-bepaald">Nog niet bepaald</option><option value="minder-dan-500">Minder dan €500</option><option value="500-1000">€500 – €1.000</option><option value="1000-2500">€1.000 – €2.500</option><option value="2500-plus">€2.500+</option><option value="eerst-overleggen">Eerst overleggen</option></select></div>
            <div className="sm:col-span-2"><label className="form-label" htmlFor="websiteUrl">Bestaande website <span className="font-normal text-[#647188]">(optioneel)</span></label><input id="websiteUrl" maxLength={500} type="url" className="input-field" value={form.websiteUrl} onChange={(e) => update('websiteUrl', e.target.value)} placeholder="https://..." data-testid="input-website-url" /></div>
            <div className="sm:col-span-2"><label className="form-label" htmlFor="timeline">Timing <span className="font-normal text-[#647188]">(optioneel)</span></label><input id="timeline" maxLength={120} className="input-field" value={form.timeline} onChange={(e) => update('timeline', e.target.value)} placeholder="Bijvoorbeeld: graag live voor september" data-testid="input-timeline" /></div>
            <div className="sm:col-span-2"><label className="form-label" htmlFor="message">Vertel iets over je project <span className="text-[#3B82F6]">*</span></label><textarea id="message" required minLength={20} maxLength={5000} rows={5} className="input-field resize-y" value={form.message} onChange={(e) => update('message', e.target.value)} placeholder="Waar wil je naartoe? Wat moet je website voor je doen?" data-testid="textarea-message" /></div>
          </div>
          <input aria-hidden="true" tabIndex={-1} autoComplete="off" className="absolute left-[-9999px] h-px w-px opacity-0" value={form.honeypot} onChange={(e) => update('honeypot', e.target.value)} name="website" />
          <label className="mt-5 flex cursor-pointer items-start gap-3 text-xs leading-5 text-[#647188]"><input type="checkbox" required checked={form.privacyAccepted} onChange={(e) => update('privacyAccepted', e.target.checked)} className="mt-1 h-4 w-4 accent-[#3B82F6]" data-testid="checkbox-privacy" /><span>Ik ga akkoord met de verwerking van mijn gegevens volgens het <Link href="/privacy" className="font-semibold text-[#0B1F3B] underline underline-offset-2" data-testid="link-form-privacy">privacybeleid</Link>.</span></label>
          {status === 'success' && <div className="mt-5 flex gap-3 rounded-xl bg-[#14D8A8]/15 p-4 text-sm text-[#0B1F3B]" role="status" data-testid="status-contact-success"><CircleCheck className="mt-0.5 shrink-0 text-[#087f68]" size={18} /><p><strong>Je aanvraag is goed aangekomen.</strong><br />We nemen je bericht persoonlijk door en komen erop terug.</p></div>}
          {status === 'error' && <div className="mt-5 rounded-xl bg-red-500/10 p-4 text-sm text-red-700" role="alert" data-testid="status-contact-error">Er ging iets mis bij het versturen. Controleer je gegevens en probeer het opnieuw.</div>}
          <p className="mt-5 text-xs leading-5 text-[#647188]">Je hoeft nog niet alle details te kennen. We nemen je bericht persoonlijk door en bespreken samen de volgende stap.</p>
          <button type="submit" disabled={mutation.isPending} className="btn-primary mt-6 w-full disabled:cursor-wait disabled:opacity-60" data-testid="button-submit-contact">{mutation.isPending ? 'Bericht wordt verstuurd…' : 'Vraag vrijblijvend informatie aan'} <ArrowUpRight size={16} /></button>
        </form>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-[#0B1F3B] py-10 text-white">
      <div className="container-wide">
        <div className="flex flex-col justify-between gap-8 border-b border-white/15 pb-10 md:flex-row md:items-end">
          <div><Logo dark /><p className="mt-5 max-w-[280px] text-sm leading-6 text-white/55">Websites met een reden, vanuit België. Voor bedrijven, zelfstandigen en projecten.</p></div>
          <div className="flex flex-wrap gap-x-6 gap-y-3 text-sm text-white/65"><a href="#diensten" className="hover:text-white" data-testid="link-footer-diensten">Diensten</a><a href="#werk" className="hover:text-white" data-testid="link-footer-werk">Portfolio</a><a href="#contact" className="hover:text-white" data-testid="link-footer-contact">Contact</a><Link href="/privacy" className="hover:text-white" data-testid="link-footer-privacy">Privacy</Link><Link href="/cookies" className="hover:text-white" data-testid="link-footer-cookies">Cookies</Link><Link href="/voorwaarden" className="hover:text-white" data-testid="link-footer-voorwaarden">Voorwaarden</Link></div>
        </div>
        <div className="flex flex-col justify-between gap-3 pt-6 font-mono-ui text-[9px] uppercase tracking-[.14em] text-white/35 sm:flex-row"><span>© {new Date().getFullYear()} GP Webstudio</span><span>Gemaakt met aandacht in België</span></div>
      </div>
    </footer>
  );
}

function About() {
  return <section id="over-ons" className="section-pad bg-[#F6F8FB]"><div className="container-wide grid gap-10 lg:grid-cols-[.8fr_1.2fr]"><div><p className="eyebrow">Over GP Webstudio</p><h2 className="mt-5 max-w-[420px] text-4xl font-semibold leading-[1.03] tracking-[-.05em] text-[#0B1F3B] sm:text-5xl">Geen template. <span className="font-display font-normal italic text-[#3B82F6]">Wel aandacht.</span></h2></div><div className="max-w-[620px]"><p className="text-2xl leading-[1.15] tracking-[-.03em] text-[#0B1F3B] sm:text-3xl">GP Webstudio helpt bedrijven en ondernemers om professioneel online zichtbaar te worden — met een website die past bij hun verhaal, doelgroep en volgende stap.</p><p className="mt-7 max-w-[530px] leading-7 text-[#647188]">Van de eerste structuur tot de laatste afwerking werken we persoonlijk en begrijpelijk. Geen standaard template die voor iedereen hetzelfde is, maar een digitale plek die echt bij de onderneming hoort.</p></div></div></section>;
}

function PricingAndFaq() {
  const faqs = [
    ['Wat kost een website?', 'Iedere website is anders. Daarom maken we een voorstel op basis van wat jouw bedrijf echt nodig heeft, zodat je niet betaalt voor functies die je niet gebruikt.'],
    ['Hoe lang duurt het maken van een website?', 'Dat hangt af van de omvang, inhoud en feedbackrondes. Na een eerste gesprek krijg je een realistische inschatting van timing en stappen.'],
    ['Kunnen jullie mijn bestaande website vernieuwen?', 'Ja. We kunnen een bestaande website inhoudelijk, visueel en technisch aanscherpen zonder zomaar weg te gooien wat al goed werkt.'],
    ['Maken jullie ook webshops en boekingswebsites?', 'Ja. Webshops, boekingsflows, landingspagina’s en maatwerkfuncties kunnen deel uitmaken van het project.'],
    ['Kan ik later functies laten toevoegen?', 'Ja. We bouwen met ruimte voor groei, zodat je website kan meegroeien wanneer je aanbod of werking verandert.'],
    ['Werkt mijn website ook op mobiel?', 'Ja. Elke website wordt gemaakt om professioneel te werken op smartphone, tablet en desktop.'],
  ];
  return (
    <section className="section-pad bg-[#eaf0f6]">
      <div className="container-wide grid gap-12 lg:grid-cols-[.72fr_1.28fr]">
        <div>
          <p className="eyebrow">Goed om te weten</p>
          <h2 className="mt-5 max-w-[400px] text-4xl font-semibold leading-[1.02] tracking-[-.05em] text-[#0B1F3B] sm:text-5xl">Nog vragen? <span className="font-display font-normal italic text-[#3B82F6]">Logisch.</span></h2>
          <p className="mt-6 max-w-[355px] leading-7 text-[#647188]">Je hoeft nog niet alles te weten voordat je contact opneemt. We denken mee over wat nodig is, wat later kan en wat je beter achterwege laat.</p>
          <a href="#contact" className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-[#0B1F3B] underline decoration-[#14D8A8] decoration-2 underline-offset-8" data-testid="link-faq-contact">Vraag vrijblijvend naar de mogelijkheden <ArrowUpRight size={15} /></a>
        </div>
        <div className="border-t border-[#0B1F3B]/15">
          {faqs.map(([question, answer]) => (
            <details key={question} className="group border-b border-[#0B1F3B]/15">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-5 py-5 text-base font-bold text-[#0B1F3B] marker:hidden">
                {question}
                <span className="font-mono-ui text-lg font-normal text-[#3B82F6] transition-transform group-open:rotate-45">+</span>
              </summary>
              <p className="max-w-[650px] pb-5 pr-10 text-sm leading-6 text-[#647188]">{answer}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function Home() {
  const structuredData = {
    '@context': 'https://schema.org',
    '@graph': [
      { '@type': 'ProfessionalService', name: 'GP Webstudio', description: 'Belgische webstudio voor websites op maat voor bedrijven, zelfstandigen en projecten.', areaServed: 'BE', serviceType: 'Webdesign en webontwikkeling', url: window.location.origin },
      { '@type': 'WebSite', name: 'GP Webstudio', url: window.location.origin, inLanguage: 'nl-BE' },
    ],
  };
  return <div className="site-shell"><Seo title="GP Webstudio — websites die voor jouw bedrijf werken" description="GP Webstudio bouwt websites op maat die jouw bedrijf professioneel presenteren en bezoekers richting contact, offerte of aankoop begeleiden." path="/" structuredData={structuredData} /><Header /><main><Hero /><IntroBand /><WhyWebsite /><Services /><Portfolio /><Approach /><About /><PricingAndFaq /><Contact /></main><Footer /></div>;
}

function LegalPage({ title, kind }: { title: string; kind: 'privacy' | 'voorwaarden' | 'cookies' }) {
  const descriptions = {
    privacy: 'Lees hoe GP Webstudio omgaat met contactgegevens en privacy.',
    voorwaarden: 'Lees de algemene afspraken voor een samenwerking met GP Webstudio.',
    cookies: 'Lees welke cookies GP Webstudio gebruikt en waarom.',
  };
  return <div className="min-h-[100dvh] bg-[#F6F8FB]"><Seo title={`${title} — GP Webstudio`} description={descriptions[kind]} path={`/${kind}`} /><header className="border-b border-[#0B1F3B]/10 bg-[#F6F8FB]"><div className="container-wide flex h-[78px] items-center justify-between"><Logo /><Link href="/" className="btn-secondary py-2.5 text-[13px]" data-testid="link-legal-home">Terug naar home <ArrowUpRight size={15} /></Link></div></header><main className="container-wide max-w-[800px] pb-24 pt-20"><p className="eyebrow">GP Webstudio</p><h1 className="mt-5 text-5xl font-semibold tracking-[-.06em] text-[#0B1F3B]">{title}</h1><div className="legal-copy mt-10 text-[15px]">{kind === 'privacy' ? <><p>We behandelen je contactgegevens met zorg. Wanneer je het formulier invult, gebruiken we je gegevens uitsluitend om je aanvraag te begrijpen, te beantwoorden en — als dat relevant is — verder te bespreken.</p><h2>Welke gegevens ontvangen we?</h2><p>Naam, contactgegevens en de informatie die je zelf in het bericht meegeeft. We vragen geen gegevens die niet nodig zijn voor een eerste gesprek.</p><h2>Contact</h2><p>Vragen over je gegevens kun je via het contactformulier stellen. We helpen je graag verder.</p></> : kind === 'cookies' ? <><p>Deze website gebruikt alleen cookies die technisch noodzakelijk zijn om de site goed en veilig te laten werken. Er worden geen marketing- of analysecookies geladen zolang daar geen afzonderlijke toestemming voor is.</p><h2>Geen onnodige tracking</h2><p>Er is op dit moment geen externe analyse- of advertentietool actief. Daarom tonen we geen cookiebanner die je voor noodzakelijke functionaliteit moet wegklikken.</p></> : <><p>Deze pagina beschrijft in gewone taal wat je mag verwachten wanneer je met GP Webstudio samenwerkt. Concrete afspraken over scope, timing en prijs leggen we altijd helder vast vóór de start.</p><h2>Heldere afspraken</h2><p>Een project start nadat de inhoud van de opdracht, de timing en de prijs samen zijn bevestigd. Wijzigingen bespreken we vooraf, zodat niemand voor verrassingen komt te staan.</p><h2>Samenwerking</h2><p>We werken in korte feedbackrondes. Jij zorgt tijdig voor input en goedkeuring; wij zorgen voor voortgang, uitleg en een zorgvuldige oplevering.</p></>}</div></main><Footer /></div>;
}

function NotFoundPage() {
  return <div className="flex min-h-[100dvh] flex-col bg-[#0B1F3B] text-white"><header className="container-wide flex h-[78px] items-center"><Logo dark /></header><main className="container-wide flex flex-1 flex-col justify-center pb-24"><p className="eyebrow text-[#14D8A8]">404 / Niet gevonden</p><h1 className="mt-6 max-w-[680px] text-6xl font-semibold leading-[.92] tracking-[-.06em] sm:text-8xl">Deze pagina is even <span className="font-display font-normal italic text-[#3B82F6]">verdwaald.</span></h1><p className="mt-7 max-w-[430px] leading-7 text-white/60">De link klopt niet meer of deze pagina bestaat nog niet. Terug naar een plek met richting?</p><Link href="/" className="btn-primary mt-9 w-fit bg-[#14D8A8] text-[#0B1F3B] hover:bg-[#32e4ba]" data-testid="link-404-home">Naar de homepage <ArrowUpRight size={16} /></Link></main></div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route path="/privacy"><LegalPage title="Privacybeleid" kind="privacy" /></Route><Route path="/cookies"><LegalPage title="Cookiebeleid" kind="cookies" /></Route><Route path="/voorwaarden"><LegalPage title="Algemene voorwaarden" kind="voorwaarden" /></Route><Route component={NotFoundPage} /></Switch></RoutedErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;