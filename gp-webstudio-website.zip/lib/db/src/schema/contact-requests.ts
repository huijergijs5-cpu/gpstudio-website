import { boolean, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const contactRequestsTable = pgTable("contact_requests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  company: text("company"),
  email: text("email").notNull(),
  phone: text("phone"),
  websiteType: text("website_type").notNull(),
  websiteUrl: text("website_url"),
  budget: text("budget").notNull(),
  timeline: text("timeline"),
  message: text("message").notNull(),
  privacyAccepted: boolean("privacy_accepted").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertContactRequestSchema = createInsertSchema(contactRequestsTable);
export type InsertContactRequest = typeof contactRequestsTable.$inferInsert;
export type ContactRequest = typeof contactRequestsTable.$inferSelect;